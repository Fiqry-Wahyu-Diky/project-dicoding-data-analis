# project-dicoding-data-analis
 
link app: https://e-commerceanalysis.streamlit.app/ 
